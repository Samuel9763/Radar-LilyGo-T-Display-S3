#ifndef PAGE2_H
#define PAGE2_H

#include <TFT_eSPI.h>
#include "RadarData.h"

void showPage2(TFT_eSPI &tft, TFT_eSprite &background,RadarData &radarData);

#endif
