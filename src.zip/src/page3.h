#ifndef PAGE3_H
#define PAGE3_H

#include <TFT_eSPI.h>
#include "RadarData.h"

void showPage3(TFT_eSPI &tft, TFT_eSprite &background,RadarData &radarData);

#endif
