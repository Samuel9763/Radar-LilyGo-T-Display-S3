#ifndef PAGE5_H
#define PAGE5_H

#include <TFT_eSPI.h>
#include "RadarData.h"

void showPage5(TFT_eSPI &tft, TFT_eSprite &background,RadarData &radarData);

#endif
