#ifndef PAGE1_H
#define PAGE1_H

#include <TFT_eSPI.h>
#include "RadarData.h"

void showPage1(TFT_eSPI &tft, TFT_eSprite &background,RadarData &radarData);

#endif
