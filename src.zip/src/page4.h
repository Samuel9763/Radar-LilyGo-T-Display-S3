#ifndef PAGE4_H
#define PAGE4_H

#include <TFT_eSPI.h>
#include "RadarData.h"

void showPage4(TFT_eSPI &tft, TFT_eSprite &background,RadarData &radarData);

#endif
